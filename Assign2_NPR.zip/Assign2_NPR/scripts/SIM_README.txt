Run the simulations from scripts/ folder
bat-files should include stuff needed, if basic_run.tcl has been run at least once.


More info:

https://www.xilinx.com/support/documentation/sw_manuals/xilinx2019_1/ug937-vivado-design-suite-simulation-tutorial.pdf kappaleesta Lab 3
https://www.fpgarelated.com/showthread/comp.arch.fpga/119716-1.php
https://www.xilinx.com/support/answers/63985.html
