rm ./*jou
rm ./*.log
rm ./*.wdb
rm ./*.pb
rm -rf ./xsim.dir
rm ./usage_statistics_webtalk.*
