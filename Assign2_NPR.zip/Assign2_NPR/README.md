# Repo usage:

Run (modifications propably needed, because of different paths)

`start_vivado.bat`

which starts vivado in tcl-mode. Alternatively you can start vivado in tcl-mode from windows menus.

In vivado, run

`source tcl/all.tcl`

or some other commands from tcl-folder.


